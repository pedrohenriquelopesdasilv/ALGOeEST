usuario=input("Insira o usuario: ")
senha=int(input("Insira a senha: "))

if usuario == "gabriel" and (senha == 1701):
    print("Bem vindo")
else:
    print("Algo está errado")