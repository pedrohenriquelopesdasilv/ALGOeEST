usuario=input("Insira o nome de usuário:")
senha=input("Insira a senha:")
if usuario == "admin" and senha == "1234":
    print("Bem-Vindo a sua conta bancária")
else:
    print("Usuário ou senha incorreta")