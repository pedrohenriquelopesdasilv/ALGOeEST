num1=int(input("Insira o primeiro número: "))
num2=int(input("Insira o segundo número: "))

# soma=num1+num2
# sub=num1-num2
# mult=num1*num2
# print(f"A soma deles é: {soma}, a subtração é: {sub}, a multiplicação é: {mult}")

if num1>num2:
    print(num1)
else:
    print(num2)

