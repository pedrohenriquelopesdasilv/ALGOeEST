num1=int(input("Insira o 1° número: "))
num2=int(input("Insira o 2° número: "))
escolha=int(input("1-Adição, 2-Subtração, 3-Multiplicação, 4-Divisão: "))
if escolha == 1:
    print(num1+num2)
if escolha == 2:
    print(num1-num2)
if escolha ==3:
    print(num1*num2)
if escolha ==4:
    print(num1/num2)
