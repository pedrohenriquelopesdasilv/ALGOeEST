num=int(input("Insira o número: "))
if num%2 == 0:
    print(f"{num} é par")
else:
    print(f"{num} é impar")