idade=int(input("Insira sua idade"))
if idade>18:
    print("É maior de 18")
else:
    print("É de menor")