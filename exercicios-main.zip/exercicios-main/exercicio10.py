valor=int(input("Insira o valor da compra: "))
if valor>100:
    print(f"O valor da sua compra é de{valor*0.9}")
else:
    print(f"O valor da sua compra é de {valor}")