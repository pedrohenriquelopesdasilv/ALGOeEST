nome=input("Insira seu nome:")
idade=(int(input("Insira sua idade: ")))


print(f"Olá, {nome}! Você tem {idade} anos")

