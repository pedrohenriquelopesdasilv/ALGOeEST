numero = 17
palpite = 0
i = 0
palpites = []
while palpite != numero and < 20:
    palpite = int(input("Insira um número entre 1 e 20: "))


