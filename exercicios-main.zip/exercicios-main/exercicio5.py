num=int(input("Insira um número"))
if num<0:
    print("O número é negativo")
if num>0:
    print("O número é positivo")
if num == 0:
    print("O número é 0")