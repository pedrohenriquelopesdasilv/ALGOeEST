temp=int(input("Insira a temperatura atual"))
if temp>=27:
    print("Está quente")
if temp<20:
    print("Está frio")
if temp>=20:
    print("Está morno")